package io.gonative.android;

public class JsResultBridge {
    public static String jsResult = "";
}
