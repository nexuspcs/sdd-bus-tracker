package io.gonative.android;

public class HelperClass {
    public volatile static int newLoad = 0;
}
